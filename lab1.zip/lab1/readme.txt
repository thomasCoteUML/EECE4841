readme.txt

Thomas Cote
Umass Lowell
EECE4841

SCOPE:
This readme file is create to describe the configuration of Thomas Cote's lab 1 submission for UML:EECE4841

End of Header

RUN AND COMPLING INSTRUNCTIONS

If nessecary run in command line
chmod u+x lab1RUN.sh
This issues permissions to lab1RUN.sh for it to run as a bash script

to compile and run lab1 
./lab1RUN.sh

File Descriptions

Instructor Provided Files
clover.pgm

Generated Files:
CoteLib.c
CoteLib.h
lab1.c
lab1RUN.sh
makefile
readme.txt

CoteLib.h - A library definition file for a personal library I intend to use throughout this class

CoteLib.c - A c program containing the implimentation of functions for the aforementioned personal library

lab1.c - A c program containing a pixel processing function and the main function for this lab

lab1RUN.sh - A bash script that will compile and run my lab1 main function while providing updates on progress to the command line

makefile - A GNU make makefile to compile my code

readme.txt - see SCOPE


